---
name: n8n-system-message-writer
description: Write or refine system messages/system prompts for n8n AI Agent nodes (including Tools Agent, Conversational Agent, and AI Agent Tool sub-nodes). Use this skill whenever the user asks to write, draft, create, improve, fix, or review a system message, system prompt, or agent prompt for n8n — even if they just describe an agent they want to build (e.g. "I need an agent that handles hotel reservations" or "write me a system prompt for a support bot") without explicitly saying "n8n" or "system message." Also trigger when the user pastes an existing system message and asks for feedback, a rewrite, or wants it "made more professional," since that is a refine-mode request for this skill. Always use this skill for n8n AI Agent system message work rather than writing a generic prompt from scratch — it enforces a specific structure (Role/Tone/Instructions/Goal) and a defect-check pass that generic prompting will miss.
---

# n8n System Message Writer

Writes and refines system messages for n8n AI Agent nodes (Tools Agent, Conversational Agent, AI Agent Tool sub-nodes). Produces a fixed four-section structure — **Role, Tone, Instructions, Goal** — and runs every draft through a built-in defect checklist before presenting it, because the failure modes here are structural and recur across almost every multi-tool, state-changing agent (reservations, CRUD against a calendar/sheet/inbox, anything with an undo path).

## Core principle: thorough, not padded

Every section must be fully specified — no vague placeholders, no "etc.", no unbounded scope grants. But more words is not the goal. n8n resends the full system message on every call, so padding has a real, recurring cost (tokens, money, and diluted attention on the constraints that actually matter). If a sentence doesn't add a constraint, a procedure, or a fact the agent needs, cut it.

## Step 1: Determine mode

- **Build mode**: user describes an agent that doesn't exist yet as a system message.
- **Refine mode**: user pastes an existing system message and wants it improved, fixed, or reviewed.

Both modes converge on the same output format and both go through the defect checklist (Step 4) — refine mode just starts from their draft instead of a blank page.

## Step 2: Clarify before drafting (always, if input is vague)

Do not guess at a full draft when these are missing. Ask before writing. At minimum, get answers on:

1. **Tools/integrations connected** — exact node names if known (e.g. "Google Calendar," "Google Sheets," "Gmail"). If the user doesn't know exact tool names, note in the output that tool references should be checked against the actual connected node names in their n8n canvas.
2. **Identity/verification requirements** — what must be confirmed before the agent takes a state-changing action (booking, canceling, deleting, sending), and whether verification needs to be *consistent* across all operations (see defect #4 in the checklist — this is a common gap).
3. **Edge cases / escalation path** — what the agent should refuse, defer, or hand off to a human, and how (e.g. "say X and stop" vs. "tag a Slack channel").
4. **Tone reference point** if not stated (e.g. "like a 5-star hotel receptionist" vs. "casual support chat").

If the user has already supplied all of this (common in refine mode, since the draft itself reveals tools/flow), skip straight to Step 3.

## Step 3: Write the four sections

### 1. Role
Who the agent is, what it's named (if given a persona), and what it does — bounded, not open-ended. Avoid scope-creep phrases like "and every other task a [role] does." If the agent has a name/persona, state it plainly. State the domain boundary explicitly: what this agent handles and, briefly, what it doesn't (detailed refusals belong in Instructions, but Role should make the boundary visible up front).

### 2. Tone
Concrete enough to constrain output, not just an adjective. "Professional" alone is weak; "polite and professional like a 5-star hotel receptionist — never overly casual, even if the customer is" is a usable constraint. Include how the agent should handle a customer/user who is rude, confused, or overly casual, if relevant to the use case.

### 3. Instructions
This is the longest section and always covers, explicitly:

- **Step-by-step procedures** for each task the agent performs, in the order operations should actually happen. Pay special attention to **operation ordering for anything destructive or state-changing** — e.g. confirm the new state exists and is valid *before* destroying the old state (the reverse order is a real defect: see checklist #5).
- **Tool-use guidance**: when to call which tool, with what inputs, and what to do with the output. Reference tools by the name the user gave you; if exact node/tool names weren't confirmed in Step 2, flag this explicitly in the output rather than inventing plausible-sounding tool names.
- **Verification/identity requirements**, applied *consistently* across every operation that changes state — not just the first one (creating a booking) while later ones (canceling it) get a weaker check.
- **Error handling**: what the agent does when a tool call returns nothing, returns multiple ambiguous matches, fails outright, or when the user provides invalid/incomplete input. Never leave this implicit.
- **Scope boundaries**: what the agent must refuse or escalate, and the exact escalation action (say a specific phrase, stop and wait, notify a human via a named channel/tool). Draw this boundary precisely — don't let a broad exclusion (e.g. "no billing matters") accidentally swallow a routine in-scope capability (e.g. sharing the business's own payment/bank details so a customer can pay). If the agent needs to share static sensitive-looking data (bank details, account numbers), give it verbatim and tell the agent not to alter or guess at any field, and scope exactly when it's appropriate to share (e.g. only in connection with an actual booking, not unconditionally).
- Use numbered steps or clear subheadings per task/flow, not walls of prose held together by capitalization. Capital letters are not a substitute for structure.

### 4. Goal
Not a one-line objective. State what **done correctly** looks like — the success condition the agent (and you) can check a transcript against. Format: "This agent is working correctly when [specific, checkable conditions]." Include the failure-handling success condition too — e.g. "...or, when it cannot complete the request, it has clearly told the user why and escalated via [path]."

## Step 4: Run the defect checklist before presenting output

Before showing the user the finished system message, check it against this list. Fix what you find — don't just present a checklist to the user instead of a fixed draft.

1. **Tool names** — does every tool reference match a name the user actually confirmed, or is something invented/assumed? Flag uncertain ones.
2. **Verification consistency** — is the identity/permission check for one operation (e.g. booking) at least as strong as for any other operation that changes or destroys the same data (e.g. canceling)? Inconsistent rigor is a defect even if each individual check looks reasonable alone.
3. **Error paths** — for every tool call in Instructions, is there a stated fallback for: no result, multiple/ambiguous results, and tool failure? If any are missing, add them.
4. **Scope boundaries** — does the agent have an explicit refuse/escalate instruction for out-of-scope requests, or is scope only implied by the Role description? Implied scope isn't enough — add an explicit instruction. Also check the reverse error: does an exclusion (e.g. "no billing matters") accidentally rule out something that should be in scope (e.g. sharing the business's own payment details for a routine booking)? Narrow the exclusion if so.
5. **Operation ordering** — for any flow that modifies or deletes existing state (updates, cancellations, edits), does it confirm/create the new state before destroying the old state? If the draft deletes first, flag and reorder.
6. **Padding vs. completeness** — is anything repeated, restating a constraint already covered, or present without adding a rule/fact/procedure? Cut it. Conversely, is anything load-bearing left vague ("handle errors gracefully" with no specifics)? Make it concrete.
7. **No Goal section / no success criteria** — confirm Goal exists and is checkable, not just aspirational ("be helpful").

## Step 5: Present the output

Show the finished four-section system message in full. After it, briefly note (a) any assumptions made because the user didn't specify something minor, and (b) any defects caught and fixed in Step 4 worth flagging — particularly tool names that need verification against the actual n8n canvas, since that's the one thing you cannot confirm yourself.

If the user is in refine mode, it's fine — and often clearer — to show what changed and why for the significant fixes, not just the final text silently replacing their draft.
